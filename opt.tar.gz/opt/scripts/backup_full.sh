#!/bin/bash


if [ "$1" == "-help" ] || [ "$#" -ne 2 ]; then
	echo "Uso: $0 <origen> <destino>"
	echo " origen : directorio a backupear"
	echo " destino : directorio donde se guardará el backup"
	echo " -help : muestra esta ayuda"
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio de origen  '$ORIGEN' no existe o no está disponible."
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio de destino '$DESTINO' no existe o no está disponible."
	exit 1
fi

FECHA=$(date +%Y%m%d)

NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${DESTINO}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO_BACKUP" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

if [ $? -eq 0 ]; then
	echo "Backup completado correctamente: $ARCHIVO_BACKUP"
else
	echo "Error: falló la creación del backup."
	exit 1
fi

