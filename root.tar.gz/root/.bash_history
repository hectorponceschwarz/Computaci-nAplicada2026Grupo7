history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
sudo apt updat
sudo apt update
ping -c 4 8.8.8.8
cat /etc/resolv.conf
sudo vi /etc/apt/sources.list
clear
cat /etc/resolv.conf
sudo vi /etc/resolv.conf
ping -c 4 google.com
sudo apt update
cat /etc/resolv.conf
ping -c 4 debian.org
clear
sudo vi /etc/apt/sources.list
cat /etc/apt/sources.list
sudo vi /etc/apt/sources.list
clear
cat /etc/apt/sources.list
sudo apt update
sudo apt upgrade -y
me salió un cartel que "el gestor de inicio grub se instaló previamente en un disco que ya no está presente...."
clear
sudo apt upgrade --without-new-pkgs -y
sudo apt full-upgrade -y
sudo reboot
clear
cat /etc/fstab
nano /etc/fstab
clear
reboot
systemctl status apache2
php -v
apache2ctl -M | grep php
clear
df -h | grep sdb
ls -la /www_dir/
clear
mount /dev/sdb1 /www_dir
mount /dev/sdb2 /backup_dir
ls -la /www_dir/
blkid /dev/sdb1 /dev/sdb2
nano /etc/fstab
clear

clear
nano /etc/fstab
clear
echo "UUID=$(blkid -s UUID -o value /dev/sdb1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdb1) /backup_dir ext4 defaults 0 2" >> /etc/fstab
cat /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdb2) /backup_dir ext4 defaults 0 2" >> /etc/fstab

nano /etc/fstab
clear
nano /etc/fstab
clear
mount -a
reboot
